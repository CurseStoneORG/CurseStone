#pragma once
#include "ItemTool.h"
namespace mcppeserver::item {
class ItemHoeGolden : public ItemTool {
public:
    ItemHoeGolden() : ItemTool(294, ToolType::HOE, ToolMaterial::TOOL_GOLD) {}
    std::string name() const override { return "ItemHoe Golden"; }
};
} // namespace
