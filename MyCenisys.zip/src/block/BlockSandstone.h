#pragma once
#include "BlockSolid.h"
namespace mcppeserver::block {
class BlockSandstone : public BlockSolid {
public:
    uint8_t id() const override { return SANDSTONE; }
    std::string name() const override { return "Sandstone"; }
};
} // namespace
