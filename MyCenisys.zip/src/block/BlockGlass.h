#pragma once
#include "BlockTransparent.h"
namespace mcppeserver::block {
class BlockGlass : public BlockTransparent {
public:
    uint8_t id() const override { return GLASS; }
    std::string name() const override { return "Glass"; }
};
} // namespace
